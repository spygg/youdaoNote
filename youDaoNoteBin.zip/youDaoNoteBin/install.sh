sudo mkdir /opt/youDaoNote/
sudo cp -r ./* /opt/youDaoNote/
sudo cp ./YoudaoNote.desktop /usr/share/applications/